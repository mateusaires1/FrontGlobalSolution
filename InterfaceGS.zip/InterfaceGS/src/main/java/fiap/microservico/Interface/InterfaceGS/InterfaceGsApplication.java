package fiap.microservico.Interface.InterfaceGS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterfaceGsApplication {

	public static void main(String[] args) {
		SpringApplication.run(InterfaceGsApplication.class, args);
	}

}
