package fiap.microservico.Interface.InterfaceGS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterfaceGsApplicationTests {

	@Test
	void contextLoads() {
	}

}
